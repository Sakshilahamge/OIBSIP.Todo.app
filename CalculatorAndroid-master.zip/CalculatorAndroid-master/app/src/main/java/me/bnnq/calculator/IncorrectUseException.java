package me.bnnq.calculator;

public class IncorrectUseException extends Exception {
    public IncorrectUseException(String message) {
        super(message);
    }
}
