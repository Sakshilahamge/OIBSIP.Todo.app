package me.bnnq.calculator;

public class UnexpectedBehaviorException extends Exception {
    public UnexpectedBehaviorException(String message) {
        super(message);
    }
}
